# Слито в https://t.me/HACKER_PHONE_VIP

API_TOKEN =                 '5108835048:AAE-eaxFv1l5Gg1nTdpDmjhspc7Onpe4bcE' # Токен бота! Брать с @BotFather
admin = 1815883518 # ID Админа, тобишь твой! Брать с @getmyid_bot

# Слито в https://t.me/HACKER_PHONE_VIP
